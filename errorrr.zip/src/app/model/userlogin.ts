export class Login{
     userId:number;
     userName:String;
     password:String
}