export class Rating{
    value:String;
    name:String
}