import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/app/model/employeedetails';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeedetailsService } from 'src/app/service/employeedetails.service';
import { Mode } from 'src/app/model/mode';

@Component({
  selector: 'app-userid',
  templateUrl: './userid.component.html',
  styleUrls: ['./userid.component.css']
})
export class UseridComponent implements OnInit {
 
  candidateName:String;
  bjdes2:String
cides: String;
crating: String;
esign: String;
fdes: String;
hcomment:String;
hirecomment:String;
idate: String;
ides: String;
iempcode:number;
interName: String;
kwdes: String;
l1Id: number;
location: String;
mode:String
prating: String
psdes1: String;
rcomment: String;

releventExp: String;
sdes: String;
skill: String;
ta1: String;
ta2: String;
ta3: String;
totalExp: String;
rating1:String;
rating2:String;
rating3:String;
rating4:String;
rating5:String;
rating6:String
rating7:String;
rating8:String
rating9:String;
rating10:String
  employee: EmployeeDetails = new EmployeeDetails();
  ngForm: FormGroup;
  ID:number;
  constructor( private employeeDetailsService: EmployeedetailsService) { }

  ngOnInit() {
  
    this.getEmpl();
   
  }
  getEmpl(){
    this.ID=parseInt(localStorage.getItem("userid"));
    this.employeeDetailsService.getEmployeeDetails(this.ID).subscribe(res=>{
      this.employee=res;
      this.candidateName=this.employee.candidateName;
      this.cides=this.employee.cides;
      this.crating=this.employee.crating;
      this.esign=this.employee.esign
      this.fdes=this.employee.fdes
      this.hcomment=this.employee.hcomment
      this.hirecomment=this.employee.hirecomment
      this.idate=this.employee.idate;
      this.ides=this.employee.ides;
      this.iempcode=this.employee.iempcode;
      this.interName=this.employee.interName;
      this.kwdes=this.employee.kwdes;
      this.location=this.employee.location
      this.psdes1=this.employee.psdes1
      this.rcomment=this.employee.rcomment;
      this.releventExp=this.employee.releventExp
      this.sdes=this.employee.sdes;
      this.ta1=this.employee.ta1;
      this.ta2=this.employee.ta2
      this.ta3=this.employee.ta3;
      this.totalExp=this.employee.totalExp;
      this.bjdes2=this.employee.bjdes2;
      this.mode=this.employee.mode
      this.idate=this.employee.idate
      this.rating1=this.employee.rating1
      this.rating2=this.employee.rating2
      this.rating3=this.employee.rating3
      this.rating4=this.employee.rating4
      this.rating5=this.employee.rating5
      this.rating6=this.employee.rating6
      this.rating7=this.employee.rating7
      this.rating8=this.employee.rating8
      this.rating9=this.employee.rating9
      this.rating10=this.employee.rating10
     
      console.log(this.employee.candidateName);
      console.log(res)
    })
      }

}
