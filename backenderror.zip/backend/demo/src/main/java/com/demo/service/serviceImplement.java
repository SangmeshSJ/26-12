package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.loginTable;
import com.demo.repo.UserRepository;
@Service
public class serviceImplement implements ServiceImpl {

	@Autowired
	private UserRepository userRepo ;
	
	@Override
	public String Login(loginTable login) {
		System.out.println("inside login");
		userRepo.save(login);
	//	Optional<login> userlogin = userRepo.findByUsernameAndPassword(login.getUsername(), login.getPassword());
		//login  loginuser = userRepo.findByUserNameAndPassword(login.getUserName(),login.getPassword());
		//if(userlogin != null)
		return "login Successfully";
		//return "Invalid User";
	}
	


}
