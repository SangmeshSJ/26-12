package com.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.entity.Skill;
@Repository
public interface skills extends JpaRepository<Skill, String> {

	Skill save(Skill skill);

}
