package com.demo.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.entity.loginTable;

@Repository
public interface UserRepository extends JpaRepository<loginTable, Long> {
// Optional<login> findByUsernameAndPassword(String userName , String password);

loginTable findByUserName(String Username);
}




