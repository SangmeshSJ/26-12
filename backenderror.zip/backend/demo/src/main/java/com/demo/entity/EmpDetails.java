package com.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class EmpDetails {


	@Id
	@GeneratedValue
	private int l2Id;
	@OneToOne
	private EmployeeDetails l1Id;
	private String candidateName;
	private String idate;
	private String Bu;
	private String totalExp;
	private String releventExp;
	private String psdes1;
	private String odes1;
	private String bsdes1;
	private String cdes1;
	private String dtdes1;
	private String fdes1;
	private String ppdes1;
	private String mdes1;
    private String gdes1;
    private String rdes1;
    private String interName;
 
	private String hirecomment;
	private String rcomment;
	private String hcomment;
	private String iempcode;
	private String esign;
    
	
	
	 public String getInterName() {
			return interName;
		}
		public void setInterName(String interName) {
			this.interName = interName;
		}
	
	public String getPpdes1() {
		return ppdes1;
	}
	public void setPpdes1(String ppdes1) {
		this.ppdes1 = ppdes1;
	}
	public String getHirecomment() {
		return hirecomment;
	}
	public void setHirecomment(String hirecomment) {
		this.hirecomment = hirecomment;
	}
	public String getRcomment() {
		return rcomment;
	}
	public void setRcomment(String rcomment) {
		this.rcomment = rcomment;
	}
	public String getHcomment() {
		return hcomment;
	}
	public void setHcomment(String hcomment) {
		this.hcomment = hcomment;
	}
	public String getIempcode() {
		return iempcode;
	}
	public void setIempcode(String iempcode) {
		this.iempcode = iempcode;
	}
	public String getEsign() {
		return esign;
	}
	public void setEsign(String esign) {
		this.esign = esign;
	}
	public String getPsdes1() {
		return psdes1;
	}
	public void setPsdes1(String psdes1) {
		this.psdes1 = psdes1;
	}
	public String getOdes1() {
		return odes1;
	}
	public void setOdes1(String odes1) {
		this.odes1 = odes1;
	}
	public String getBsdes1() {
		return bsdes1;
	}
	public void setBsdes1(String bsdes1) {
		this.bsdes1 = bsdes1;
	}
	public String getCdes1() {
		return cdes1;
	}
	public void setCdes1(String cdes1) {
		this.cdes1 = cdes1;
	}
	public String getDtdes1() {
		return dtdes1;
	}
	public void setDtdes1(String dtdes1) {
		this.dtdes1 = dtdes1;
	}
	public String getFdes1() {
		return fdes1;
	}
	public void setFdes1(String fdes1) {
		this.fdes1 = fdes1;
	}
	public String getMdes1() {
		return mdes1;
	}
	public void setMdes1(String mdes1) {
		this.mdes1 = mdes1;
	}
	public String getGdes1() {
		return gdes1;
	}
	public void setGdes1(String gdes1) {
		this.gdes1 = gdes1;
	}
	public String getRdes1() {
		return rdes1;
	}
	public void setRdes1(String rdes1) {
		this.rdes1 = rdes1;
	}
	public String getTotalExp() {
		return totalExp;
	}
	public void setTotalExp(String totalExp) {
		this.totalExp = totalExp;
	}
	public String getReleventExp() {
		return releventExp;
	}
	public void setReleventExp(String releventExp) {
		this.releventExp = releventExp;
	}
	public String getBu() {
		return Bu;
	}
	public void setBu(String bu) {
		Bu = bu;
	}
	
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getIdate() {
		return idate;
	}
	public void setIdate(String idate) {
		this.idate = idate;
	}
	public int getL2Id() {
		return l2Id;
	}
	public void setL2Id(int l2Id) {
		this.l2Id = l2Id;
	}
	public EmployeeDetails getL1Id() {
		return l1Id;
	}
	public void setL1Id(EmployeeDetails l1Id) {
		this.l1Id = l1Id;
	}
	@Override
	public String toString() {
		return "EmpDetails [l2Id=" + l2Id + ", l1Id=" + l1Id + ", candidateName=" + candidateName + ", idate=" + idate
				+ ", Bu=" + Bu + ", totalExp=" + totalExp + ", releventExp=" + releventExp + ", psdes1=" + psdes1
				+ ", odes1=" + odes1 + ", bsdes1=" + bsdes1 + ", cdes1=" + cdes1 + ", dtdes1=" + dtdes1 + ", fdes1="
				+ fdes1 + ", ppdes1=" + ppdes1 + ", mdes1=" + mdes1 + ", gdes1=" + gdes1 + ", rdes1=" + rdes1
				+ ", interName=" + interName + ", hirecomment=" + hirecomment + ", rcomment=" + rcomment + ", hcomment="
				+ hcomment + ", iempcode=" + iempcode + ", esign=" + esign + "]";
	}
	
	


	
	
}
