package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Skill;
import com.demo.repo.skills;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class EmpController {
	/*
	 * 
	 * @Autowired EmpRepo repository;
	 * 
	 * 
	 * 
	 * @GetMapping("/employees") public List<EmpDetails> getAllEmpDetails() {
	 * System.out.println("Get all Employees...");
	 * 
	 * List<EmpDetails> employees = new ArrayList<>();
	 * repository.findAll().forEach(employees::add); return employees; }
	 * 
	 * 
	 * 
	 * @PostMapping("/employees/create") public EmpDetails
	 * postEmpDetails(@RequestBody EmpDetails employee) { EmpDetails _employee =
	 * repository.save(employee); return _employee; }
	 */
	 @Autowired
	 private skills skillRepo;
	@GetMapping("/skill")
	public List<Skill> getSkill() {
		
		return skillRepo.findAll();
		
	}
}